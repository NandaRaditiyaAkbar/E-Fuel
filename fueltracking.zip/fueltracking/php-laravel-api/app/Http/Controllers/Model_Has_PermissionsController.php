<?php 
namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use App\Http\Requests\Model_Has_PermissionsAddRequest;
use App\Http\Requests\Model_Has_PermissionsEditRequest;
use App\Models\Model_Has_Permissions;
use Illuminate\Http\Request;
use Exception;
class Model_Has_PermissionsController extends Controller
{
}
