<?php 
namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use App\Http\Requests\Role_Has_PermissionsAddRequest;
use App\Http\Requests\Role_Has_PermissionsEditRequest;
use App\Models\Role_Has_Permissions;
use Illuminate\Http\Request;
use Exception;
class Role_Has_PermissionsController extends Controller
{
}
