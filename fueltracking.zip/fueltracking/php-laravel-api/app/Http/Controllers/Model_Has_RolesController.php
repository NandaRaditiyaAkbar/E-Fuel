<?php 
namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use App\Http\Requests\Model_Has_RolesAddRequest;
use App\Http\Requests\Model_Has_RolesEditRequest;
use App\Models\Model_Has_Roles;
use Illuminate\Http\Request;
use Exception;
class Model_Has_RolesController extends Controller
{
}
